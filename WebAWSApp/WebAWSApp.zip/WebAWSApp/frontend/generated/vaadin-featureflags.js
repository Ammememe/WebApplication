// @ts-nocheck
window.Vaadin = window.Vaadin || {};
window.Vaadin.featureFlags = window.Vaadin.featureFlags || {};
window.Vaadin.featureFlags.exampleFeatureFlag = false;
window.Vaadin.featureFlags.collaborationEngineBackend = false;
window.Vaadin.featureFlags.sideNavComponent = true;
export {};