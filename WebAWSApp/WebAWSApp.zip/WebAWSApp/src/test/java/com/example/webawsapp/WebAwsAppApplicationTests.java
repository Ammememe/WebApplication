package com.example.webawsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebAwsAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
