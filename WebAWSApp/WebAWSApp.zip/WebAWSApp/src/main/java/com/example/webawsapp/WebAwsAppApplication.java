package com.example.webawsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebAwsAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebAwsAppApplication.class, args);
    }

}
